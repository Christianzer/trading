<div class="col-md-4">
    <div class="form-group" id="placement">
        <label for="placement" class="col-form-label-lg font-weight-bold text-uppercase">Placement initial sur AN3</label>
        <input class="form-control form-control-lg" readonly type="text" name="placement"  value="<?php echo number_format($somme_actions_dettes,'0','.',' ') ?>">
    </div>
</div>
<div class="col-md-4">
    <div class="form-group" id="placement">
        <label for="placement" class="col-form-label-lg font-weight-bold text-uppercase">Placement total sur AN3</label>
        <input class="form-control form-control-lg" readonly type="text" name="placement"  value="<?php echo number_format($somme_actions_dettes_capital,'0','.',' ') ?>">
    </div>
</div>
<div class="col-md-4">
    <div class="form-group" id="placement">
        <label for="placement" class="col-form-label-lg font-weight-bold text-uppercase">Vente total sur AN3</label>
        <input class="form-control form-control-lg" readonly type="text" name="placement"  value="<?php echo number_format($somme_actions_dettes_ventes,'0','.',' ') ?>">
    </div>
</div>
<div class="col-md-4">
    <div class="form-group" id="placement">
        <label for="placement" class="col-form-label-lg font-weight-bold text-uppercase font-weight-bold text-danger">Actif total sur AN3</label>
        <input class="form-control form-control-lg font-weight-bold text-danger" readonly type="text" name="placement"  value="<?php echo number_format($somme_actions_dettes_total,'0','.',' ') ?>">
    </div>
</div>
<div class="col-md-4">
    <div class="form-group" id="placement">
        <label for="placement" class="col-form-label-lg font-weight-bold text-uppercase font-weight-bold text-danger">nette total sur AN3</label>
        <input class="form-control form-control-lg font-weight-bold text-danger" readonly type="text" name="placement"  value="<?php echo $somme_actions_dettes_pourcentage.'%' ?>">
    </div>
</div>